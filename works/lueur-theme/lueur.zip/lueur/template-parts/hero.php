<?php
/**
 * ファーストビュー セクション。
 *
 * @package Lueur
 */
?>
  <!-- ========================= HERO ========================= -->
  <section class="hero" aria-labelledby="hero-title">
    <div class="hero-media">
      <img src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=2000&q=80"
           alt="朝の光が差し込む喫茶店の店内。木のテーブルと椅子が並ぶ。" fetchpriority="high">
    </div>

    <div class="hero-copy">
      <p class="hero-note">Coffee &amp; Pastry — Since 2021</p>
      <h1 id="hero-title">光と影、そして<br>コーヒーの香る場所。</h1>
      <div class="hero-hours">
        <span><b>OPEN</b>8:00 – 18:00</span>
        <span><b>CLOSED</b>水曜</span>
        <span><b>ACCESS</b>池ノ上駅 徒歩5分</span>
      </div>
    </div>

    <div class="scroll-cue" aria-hidden="true"><span>Scroll</span><i></i></div>
  </section>

