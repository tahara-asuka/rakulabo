<?php
/**
 * アクセスセクション。
 * 地図は Google マップの埋め込みではなく、配色を店の世界観に合わせるため SVG で自作しています。
 *
 * @package Lueur
 */
?>
  <!-- ======================== ACCESS ======================== -->
  <section class="access" id="access" aria-labelledby="access-title">
    <div class="shell">
      <div class="section-head">
        <p class="eyebrow">Access</p>
        <h2 class="section-title" id="access-title">路地の奥、一階の窓</h2>
      </div>

      <div class="access-grid">
        <div class="reveal">
          <dl>
            <div class="info-row">
              <dt>Address</dt>
              <dd>東京都世田谷区代沢 2-14-6<br>リュールアパートメント 1F
                <small>白い外壁、真鍮の看板が目印です</small></dd>
            </div>
            <div class="info-row">
              <dt>Hours</dt>
              <dd>8:00 – 18:00
                <small>ラストオーダー 17:30 ／ 焼き菓子は売切次第終了</small></dd>
            </div>
            <div class="info-row">
              <dt>Closed</dt>
              <dd>毎週水曜日
                <small>臨時休業は Instagram にてお知らせします</small></dd>
            </div>
            <div class="info-row">
              <dt>Seats</dt>
              <dd>14席（カウンター 5／テーブル 9）
                <small>全席に電源と Wi-Fi ／ 予約は承っておりません</small></dd>
            </div>
            <div class="info-row">
              <dt>Tel</dt>
              <dd><?php echo esc_html( lueur_option( 'tel' ) ); ?></dd>
            </div>
          </dl>

          <div class="route">
            <p class="route-title">池ノ上駅から 徒歩5分</p>
            <ol class="route-steps">
              <li>南口の改札を出て、線路を背に商店街へ。</li>
              <li>三つ目の角、青い庇のクリーニング店を右へ。</li>
              <li>坂を下りきると、白い外壁のアパートが見えます。</li>
              <li>路地に入って一階、真鍮の看板が出ていれば営業中です。</li>
            </ol>
          </div>
        </div>

        <figure class="map-frame reveal" style="margin:0">
          <svg viewBox="0 0 640 400" role="img" aria-label="池ノ上駅から Cafe Lueur までの地図。駅南口から商店街を進み、三つ目の角を右折した路地の奥。">
            <rect class="mp-ground" x="0" y="0" width="640" height="400"/>

            <rect class="mp-block" x="34"  y="40"  width="150" height="96"  rx="2"/>
            <rect class="mp-block" x="34"  y="176" width="150" height="82"  rx="2"/>
            <rect class="mp-block" x="34"  y="298" width="150" height="66"  rx="2"/>
            <rect class="mp-block" x="228" y="40"  width="176" height="96"  rx="2"/>
            <rect class="mp-block" x="228" y="176" width="176" height="188" rx="2"/>
            <rect class="mp-block" x="448" y="40"  width="158" height="96"  rx="2"/>
            <rect class="mp-block" x="448" y="248" width="158" height="116" rx="2"/>

            <path class="mp-water" d="M0 366 C 120 352, 240 388, 380 370 C 480 358, 560 380, 640 372 L640 400 L0 400 Z" opacity=".55"/>

            <g class="mp-road" stroke-width="9" stroke-linecap="square">
              <path d="M0 156 H640"/><path d="M206 0 V400"/><path d="M426 136 V400"/><path d="M206 276 H640"/>
            </g>

            <g class="mp-rail">
              <path d="M0 22 H640" stroke-width="3"/>
              <path d="M0 22 H640" stroke-width="9" stroke-dasharray="3 13" opacity=".7"/>
            </g>

            <rect x="150" y="8" width="112" height="28" rx="1" fill="var(--surface)" stroke="var(--greige)" stroke-width="1"/>
            <text class="mp-label-strong" x="206" y="27" text-anchor="middle">池ノ上駅</text>
            <text class="mp-label" x="206" y="52" text-anchor="middle">南口</text>

            <text class="mp-label" x="296" y="120">商店街</text>
            <text class="mp-label" x="330" y="200">クリーニング店</text>
            <text class="mp-label" x="470" y="330">代沢公園</text>
            <text class="mp-label" x="60"  y="392">北沢川</text>

            <path d="M206 44 V150 M206 150 V270 M212 276 H420 M426 282 V206 M432 212 H466"
                  fill="none" stroke="var(--brass)" stroke-width="2.5"
                  stroke-dasharray="7 7" stroke-linecap="round" opacity=".95"/>

            <circle class="pin-pulse" cx="470" cy="214" r="9" fill="var(--brass)" opacity=".5"/>
            <circle cx="470" cy="214" r="6.5" fill="var(--brass)"/>
            <circle cx="470" cy="214" r="12"  fill="none" stroke="var(--brass)" stroke-width="1.25"/>
            <text class="mp-pin-label" x="490" y="219">Lueur</text>
          </svg>

          <figcaption class="map-caption">
            <span class="map-key"><i class="map-dot"></i>Cafe Lueur</span>
            <span class="map-key"><i class="map-dot is-station"></i>池ノ上駅（京王井の頭線）</span>
            <span class="map-key">下北沢駅からは徒歩 9 分</span>
          </figcaption>
        </figure>
      </div>
    </div>
  </section>
