<?php
/**
 * 当店について セクション。
 *
 * @package Lueur
 */
?>
  <!-- ========================= ABOUT ========================= -->
  <section class="shell" id="about" aria-labelledby="about-title">
    <div class="about-grid">
      <p class="vertical-label">当店について</p>

      <div class="about-body reveal">
        <p class="eyebrow">About</p>
        <h2 class="section-title" id="about-title">時間に、余白を。</h2>
        <p>都心の喧騒から一本入った路地に、築四十年のアパートが建っています。その一階、かつては管理人室だった六坪ほどの部屋を借りて、Lueur ははじまりました。</p>
        <p>店主がコペンハーゲンで過ごした冬に、朝いちばんの光が差し込む店で出された一杯を、今でもよく思い出します。特別な豆でも、特別な設えでもありませんでした。ただ、そこには誰も急かさない時間がありました。</p>
        <p>朝は東向きの窓から射す光を頼りにコーヒーを淹れ、日が傾けば真鍮のペンダントライトに火を入れます。壁に落ちる影の角度で、いまが何時ごろかわかるようになりました。この店で過ごす二時間が、あなたの一日の余白になれば、それでじゅうぶんです。</p>
        <p class="signature">Lueur<small>店主 — 高木 一（たかぎ はじめ）</small></p>
      </div>

      <div class="about-photos reveal">
        <figure class="photo photo--zoom" style="margin:0">
          <img src="https://images.unsplash.com/photo-1559496417-e7f25cb247f3?auto=format&fit=crop&w=1100&q=80"
               alt="窓辺の席に置かれたコーヒーカップと、差し込む午前の光。" loading="lazy">
        </figure>
        <figure class="photo photo--zoom" style="margin:0">
          <img src="https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=1100&q=80"
               alt="ドリップでコーヒーを淹れる手元。" loading="lazy">
        </figure>
      </div>
    </div>
  </section>

