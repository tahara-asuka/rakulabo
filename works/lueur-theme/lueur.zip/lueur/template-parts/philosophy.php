<?php
/**
 * こだわり セクション。
 *
 * @package Lueur
 */
?>
  <!-- ====================== PHILOSOPHY ====================== -->
  <section class="philosophy" id="philosophy" aria-labelledby="philosophy-title">
    <div class="shell">
      <div class="section-head">
        <p class="eyebrow">Philosophy</p>
        <h2 class="section-title" id="philosophy-title">三つの、ちいさなこだわり</h2>
      </div>

      <div class="pillars">
        <article class="pillar reveal">
          <figure class="photo photo--zoom" style="margin:0">
            <img src="https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&w=900&q=80"
                 alt="浅煎りのコーヒー豆とカップ。" loading="lazy">
          </figure>
          <h3>自家焙煎の、浅煎り</h3>
          <p>店の奥に置いた 3kg 釜で、週に二度だけ焙煎します。酸をきれいに残すため、一ハゼの直後で火を落とす浅めの仕上げ。豆の個性を薄めないよう、ブレンドは組みません。</p>
          <p class="pillar-meta">Roasted in-house</p>
        </article>

        <article class="pillar reveal">
          <figure class="photo photo--zoom" style="margin:0">
            <img src="https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=900&q=80"
                 alt="焼き上がったばかりの焼き菓子とパン。" loading="lazy">
          </figure>
          <h3>北海道産小麦と、キビ糖</h3>
          <p>焼き菓子はすべて、その日の朝に仕込みます。粉は北海道産の「はるゆたか」、甘みはきび砂糖のみ。バターの香りが立つよう、材料は前日から冷やしておきます。</p>
          <p class="pillar-meta">Baked each morning</p>
        </article>

        <article class="pillar reveal">
          <figure class="photo photo--zoom" style="margin:0">
            <img src="https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=900&q=80"
                 alt="真鍮のペンダントライトが灯る、夕方の店内。" loading="lazy">
          </figure>
          <h3>真鍮の灯りと、音量</h3>
          <p>照明は真鍮のペンダントを四灯だけ。音楽は北欧のジャズとアンビエントを、隣の会話が聞こえる音量で。長居していただくための設計です。Wi-Fi と電源も、全席にあります。</p>
          <p class="pillar-meta">Quiet by design</p>
        </article>
      </div>
    </div>
  </section>

