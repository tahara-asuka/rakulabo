<?php
/**
 * 店内の様子 セクション。
 *
 * @package Lueur
 */
?>
  <!-- ======================== GALLERY ======================== -->
  <section class="shell" id="gallery" aria-labelledby="gallery-title">
    <div class="section-head">
      <p class="eyebrow">Gallery</p>
      <h2 class="section-title" id="gallery-title">朝から、日が暮れるまで</h2>
    </div>

    <div class="gallery-grid reveal">
      <figure class="photo photo--zoom is-wide" style="margin:0">
        <img src="https://images.unsplash.com/photo-1521017432531-fbd92d768814?auto=format&fit=crop&w=1400&q=80"
             alt="窓際のカウンター席と、外の緑。" loading="lazy">
      </figure>
      <figure class="photo photo--zoom" style="margin:0">
        <img src="https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=800&q=80"
             alt="ソーサーに置かれた一杯のコーヒー。" loading="lazy">
      </figure>
      <figure class="photo photo--zoom" style="margin:0">
        <img src="https://images.unsplash.com/photo-1453614512568-c4024d13c247?auto=format&fit=crop&w=800&q=80"
             alt="本とノートが置かれたテーブル席。" loading="lazy">
      </figure>
      <figure class="photo photo--zoom" style="margin:0">
        <img src="https://images.unsplash.com/photo-1517433670267-08bbd4be890f?auto=format&fit=crop&w=800&q=80"
             alt="ショーケースに並ぶ焼き菓子。" loading="lazy">
      </figure>
      <figure class="photo photo--zoom is-wide" style="margin:0">
        <img src="https://images.unsplash.com/photo-1497935586351-b67a49e012bf?auto=format&fit=crop&w=1400&q=80"
             alt="夕方、灯りのともった店内。" loading="lazy">
      </figure>
      <figure class="photo photo--zoom" style="margin:0">
        <img src="https://images.unsplash.com/photo-1524350876685-274059332603?auto=format&fit=crop&w=800&q=80"
             alt="焙煎されたコーヒー豆。" loading="lazy">
      </figure>
    </div>
  </section>

