<?php
/**
 * 店内の様子 セクション。
 *
 * @package Lueur
 */
?>
  <!-- ======================== GALLERY ======================== -->
  <section class="shell" id="gallery" aria-labelledby="gallery-title">
    <div class="section-head">
      <p class="eyebrow">Gallery</p>
      <h2 class="section-title" id="gallery-title">朝から、日が暮れるまで</h2>
    </div>

    <div class="gallery-grid reveal">
      <figure class="photo photo--zoom is-wide" style="margin:0">
        <img src="https://images.unsplash.com/photo-1555172375-56a199d6164d?auto=format&fit=crop&w=1400&q=80"
             alt="窓辺の席と、外の緑。" loading="lazy">
      </figure>
      <figure class="photo photo--zoom" style="margin:0">
        <img src="https://images.unsplash.com/photo-1573150709037-c7dc76c94c66?auto=format&fit=crop&w=800&q=80"
             alt="テーブルに置かれた一杯のコーヒー。" loading="lazy">
      </figure>
      <figure class="photo photo--zoom" style="margin:0">
        <img src="https://images.unsplash.com/photo-1662733853648-329a0d258be4?auto=format&fit=crop&w=800&q=80"
             alt="窓辺のテーブル席と、一輪挿し。" loading="lazy">
      </figure>
      <figure class="photo photo--zoom" style="margin:0">
        <img src="https://images.unsplash.com/photo-1529685594910-3b12ce0b9120?auto=format&fit=crop&w=800&q=80"
             alt="焼き上がった菓子が並ぶ、厨房の棚。" loading="lazy">
      </figure>
      <figure class="photo photo--zoom is-wide" style="margin:0">
        <img src="https://images.unsplash.com/photo-1621343607959-5d11ff0f1e39?auto=format&fit=crop&w=1400&q=80"
             alt="白い壁と、ペンダントライトの並ぶ店内。" loading="lazy">
      </figure>
      <figure class="photo photo--zoom" style="margin:0">
        <img src="https://images.unsplash.com/photo-1606836576983-8b458e75221d?auto=format&fit=crop&w=800&q=80"
             alt="大きな窓に面した、木のテーブル席。" loading="lazy">
      </figure>
    </div>
  </section>

