<?php
/**
 * メニュー（お品書き）セクション。
 *
 * 管理画面の「お品書き」に品目が1件でも登録されていれば、そちらを表示します。
 * まだ何も登録されていないときは、下の初期メニューをそのまま表示します。
 * （納品直後でも、ページが空にならないようにするためです）
 *
 * @package Lueur
 */

$lueur_groups = lueur_get_menu_groups();
?>
<section class="shell" id="menu" aria-labelledby="menu-title">
  <div class="section-head">
    <p class="eyebrow">Menu</p>
    <h2 class="section-title" id="menu-title">その日の一杯と、焼きたて</h2>
  </div>

  <div class="menu-groups">
<?php if ( $lueur_groups ) : ?>
<?php foreach ( $lueur_groups as $group ) : ?>
    <div class="reveal">
      <div class="menu-group-head">
<?php
        // グループの写真は、そのグループの最初の品目のアイキャッチ画像を使います。
        $lueur_thumb = '';
        foreach ( $group['items'] as $item ) {
            if ( has_post_thumbnail( $item ) ) {
                $lueur_thumb = get_the_post_thumbnail( $item, 'large', array( 'loading' => 'lazy', 'alt' => '' ) );
                break;
            }
        }
        if ( $lueur_thumb ) :
?>
        <figure class="photo photo--zoom" style="margin:0"><?php echo $lueur_thumb; // phpcs:ignore WordPress.Security.EscapeOutput ?></figure>
<?php endif; ?>
        <h3 class="menu-group-title"><?php echo esc_html( $group['term']->name ); ?></h3>
      </div>

      <dl>
<?php foreach ( $group['items'] as $item ) : ?>
        <div class="menu-item">
          <dt><?php echo esc_html( get_the_title( $item ) ); ?></dt>
          <dd><?php echo esc_html( get_post_meta( $item->ID, '_lueur_price', true ) ); ?></dd>
<?php if ( $item->post_content ) : ?>
          <p class="detail"><?php echo esc_html( wp_strip_all_tags( $item->post_content ) ); ?></p>
<?php endif; ?>
        </div>
<?php endforeach; ?>
      </dl>

<?php if ( $group['term']->description ) : ?>
      <p class="roast-note"><?php echo wp_kses_post( nl2br( $group['term']->description ) ); ?></p>
<?php endif; ?>
    </div>
<?php endforeach; ?>
<?php else : ?>
<?php /* ここから下は、まだ品目が登録されていないときに表示する初期メニューです。 */ ?>

      <div class="reveal">
        <div class="menu-group-head">
          <figure class="photo photo--zoom" style="margin:0">
            <img src="https://images.unsplash.com/photo-1530632308350-e96d55f00e4a?auto=format&fit=crop&w=1200&q=80"
                 alt="木のテーブルに置かれた、ソーサーつきのコーヒー。" loading="lazy">
          </figure>
          <h3 class="menu-group-title">Coffee</h3>
        </div>
        <dl>
          <div class="menu-item">
            <dt>フィルターコーヒー</dt><dd>¥620</dd>
            <p class="detail">中浅煎り／Hario V60・19g → 300ml。豆はその週の焙煎からお選びいただけます。</p>
          </div>
          <div class="menu-item">
            <dt>エチオピア <span class="origin">Kochere</span></dt><dd>¥780</dd>
            <p class="detail">シングルオリジン／ナチュラル精製。ベルガモット、白桃、紅茶のような後味。</p>
          </div>
          <div class="menu-item">
            <dt>グアテマラ <span class="origin">El Injerto</span></dt><dd>¥820</dd>
            <p class="detail">シングルオリジン／ウォッシュド。カカオと洋梨。ミルクにも負けません。</p>
          </div>
          <div class="menu-item">
            <dt>カフェラテ</dt><dd>¥660</dd>
            <p class="detail">中深煎りのエスプレッソに、低温殺菌牛乳を合わせて。</p>
          </div>
        </dl>
        <p class="roast-note">豆の焙煎は毎週 火曜・金曜。<br>100g からの量り売り（¥900〜）も承っています。</p>
      </div>

      <div class="reveal">
        <div class="menu-group-head">
          <figure class="photo photo--zoom" style="margin:0">
            <img src="https://images.unsplash.com/photo-1599125816289-736f5025fc05?auto=format&fit=crop&w=1200&q=80"
                 alt="棚に並んだ、その日の焼き菓子。" loading="lazy">
          </figure>
          <h3 class="menu-group-title">Pastry</h3>
        </div>
        <dl>
          <div class="menu-item">
            <dt>季節のスパイスキャロットケーキ</dt><dd>¥580</dd>
            <p class="detail">シナモンとカルダモン、くるみ。上にのせるのはサワークリームのフロスティング。</p>
          </div>
          <div class="menu-item">
            <dt>全粒粉のスコーン</dt><dd>¥420</dd>
            <p class="detail">全粒粉三割。自家製のミルクジャムを添えて。12時前に焼き上がります。</p>
          </div>
          <div class="menu-item">
            <dt>カヌレ</dt><dd>¥380</dd>
            <p class="detail">前日から生地を休ませ、蜜蝋を塗った銅型で。一日 20 個かぎり。</p>
          </div>
          <div class="menu-item">
            <dt>本日のオープンサンド</dt><dd>¥940</dd>
            <p class="detail">ライ麦のパンに、その日の惣菜を。8:00 から 11:00 まで。</p>
          </div>
        </dl>
        <p class="roast-note">表示はすべて税込です。<br>お持ち帰りの容器代は頂戴しておりません。</p>
      </div>
<?php endif; ?>
  </div>
</section>
