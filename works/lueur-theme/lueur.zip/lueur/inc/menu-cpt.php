<?php
/**
 * お品書きを、管理画面から編集できるようにする。
 *
 * WordPress の「投稿」とは別に、専用の入れ物（カスタム投稿タイプ）を作ります。
 * ・投稿タイプ : lueur_menu（1品 = 1件）
 * ・分類       : lueur_group（Coffee / Pastry などのまとまり）
 * ・追加項目   : 価格
 *
 * @package Lueur
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---- 投稿タイプと分類を登録する ---------------------------------- */
function lueur_register_menu_cpt() {

	register_post_type(
		'lueur_menu',
		array(
			'labels'       => array(
				'name'          => __( 'お品書き', 'lueur' ),
				'singular_name' => __( 'お品書き', 'lueur' ),
				'add_new_item'  => __( '品目を追加', 'lueur' ),
				'edit_item'     => __( '品目を編集', 'lueur' ),
			),
			'public'       => false,
			'show_ui'      => true,
			'show_in_menu' => true,
			'show_in_rest' => true,          // ブロックエディタで編集する
			'menu_icon'    => 'dashicons-coffee',
			'menu_position'=> 21,
			'supports'     => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
			'has_archive'  => false,
		)
	);

	register_taxonomy(
		'lueur_group',
		'lueur_menu',
		array(
			'labels'            => array(
				'name'          => __( 'メニューの分類', 'lueur' ),
				'singular_name' => __( '分類', 'lueur' ),
			),
			'public'            => false,
			'show_ui'           => true,
			'show_in_rest'      => true,
			'hierarchical'      => true,
			'show_admin_column' => true,
		)
	);
}
add_action( 'init', 'lueur_register_menu_cpt' );

/* ---- 価格の入力欄を、編集画面に足す ------------------------------ */
function lueur_register_menu_meta() {
	register_post_meta(
		'lueur_menu',
		'_lueur_price',
		array(
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'sanitize_text_field',
			'auth_callback'     => function () {
				return current_user_can( 'edit_posts' );
			},
		)
	);
}
add_action( 'init', 'lueur_register_menu_meta' );

function lueur_price_metabox() {
	add_meta_box(
		'lueur_price',
		__( '価格', 'lueur' ),
		'lueur_price_metabox_html',
		'lueur_menu',
		'side',
		'high'
	);
}
add_action( 'add_meta_boxes', 'lueur_price_metabox' );

function lueur_price_metabox_html( $post ) {
	wp_nonce_field( 'lueur_save_price', 'lueur_price_nonce' );
	$value = get_post_meta( $post->ID, '_lueur_price', true );
	printf(
		'<input type="text" name="lueur_price" value="%s" class="widefat" placeholder="&yen;620">',
		esc_attr( $value )
	);
	echo '<p class="description">' . esc_html__( '「¥620」のように、表示したい形のまま入力してください。', 'lueur' ) . '</p>';
}

function lueur_save_price( $post_id ) {
	if ( ! isset( $_POST['lueur_price_nonce'] ) || ! wp_verify_nonce( $_POST['lueur_price_nonce'], 'lueur_save_price' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	if ( isset( $_POST['lueur_price'] ) ) {
		update_post_meta( $post_id, '_lueur_price', sanitize_text_field( wp_unslash( $_POST['lueur_price'] ) ) );
	}
}
add_action( 'save_post_lueur_menu', 'lueur_save_price' );

/* ---- 表示に使うデータを取り出す ---------------------------------- */
/**
 * 分類ごとに品目をまとめて返す。
 * まだ1件も登録されていないときは false を返し、
 * テンプレート側で初期メニューを表示させます。
 */
function lueur_get_menu_groups() {

	$terms = get_terms(
		array(
			'taxonomy'   => 'lueur_group',
			'hide_empty' => true,
			'orderby'    => 'term_order',
		)
	);

	if ( is_wp_error( $terms ) || empty( $terms ) ) {
		return false;
	}

	$groups = array();

	foreach ( $terms as $term ) {
		$items = get_posts(
			array(
				'post_type'      => 'lueur_menu',
				'posts_per_page' => 20,
				'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'ASC' ),
				'tax_query'      => array(
					array(
						'taxonomy' => 'lueur_group',
						'field'    => 'term_id',
						'terms'    => $term->term_id,
					),
				),
			)
		);

		if ( $items ) {
			$groups[] = array(
				'term'  => $term,
				'items' => $items,
			);
		}
	}

	return $groups ? $groups : false;
}
