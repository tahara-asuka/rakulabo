<?php
/**
 * 「外観 > カスタマイズ」に、店舗情報の入力欄を足す。
 *
 * 営業時間や住所をテンプレートに直接書かず、ここから編集できるようにします。
 * お客様に納品したあと、ご自身で直せる状態にしておくための仕組みです。
 *
 * @package Lueur
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function lueur_customize_register( $wp_customize ) {

	$wp_customize->add_section(
		'lueur_shop',
		array(
			'title'       => __( '店舗情報', 'lueur' ),
			'priority'    => 30,
			'description' => __( 'ヘッダー・メニュー・フッターに表示される情報です。', 'lueur' ),
		)
	);

	$fields = array(
		'brand_sub'   => array( __( '店名のよみ', 'lueur' ), 'text' ),
		'hours_short' => array( __( '営業時間（短い表記）', 'lueur' ), 'text' ),
		'hours_long'  => array( __( '営業時間（詳しい表記）', 'lueur' ), 'text' ),
		'address'     => array( __( '住所', 'lueur' ), 'text' ),
		'tel'         => array( __( '電話番号', 'lueur' ), 'text' ),
		'instagram'   => array( __( 'Instagram の URL', 'lueur' ), 'url' ),
		'store'       => array( __( 'オンラインストアの URL', 'lueur' ), 'url' ),
		'email'       => array( __( '問い合わせ先メールアドレス', 'lueur' ), 'text' ),
	);

	$defaults = lueur_defaults();

	foreach ( $fields as $key => $field ) {

		$wp_customize->add_setting(
			'lueur_' . $key,
			array(
				'default'           => isset( $defaults[ $key ] ) ? $defaults[ $key ] : '',
				'sanitize_callback' => ( 'url' === $field[1] ) ? 'esc_url_raw' : 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			'lueur_' . $key,
			array(
				'label'   => $field[0],
				'section' => 'lueur_shop',
				'type'    => ( 'url' === $field[1] ) ? 'url' : 'text',
			)
		);
	}
}
add_action( 'customize_register', 'lueur_customize_register' );
