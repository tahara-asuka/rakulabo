<?php
/**
 * 固定ページ（お知らせ・プライバシーポリシーなど）。
 *
 * @package Lueur
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>
<article <?php post_class( 'shell entry-single' ); ?>>
  <div class="section-head">
    <p class="eyebrow">Page</p>
    <h1 class="section-title"><?php the_title(); ?></h1>
  </div>

  <div class="entry-body">
	<?php the_content(); ?>
  </div>
</article>
	<?php
endwhile;

get_footer();
