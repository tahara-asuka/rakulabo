<?php
/**
 * 最終的な受け皿になるテンプレート。
 *
 * 専用のテンプレートが見つからないときは、必ずこのファイルが使われます。
 * WordPress のテーマとして成立するために必須のファイルです。
 *
 * @package Lueur
 */

get_header();
?>

<section class="shell">
  <div class="section-head">
    <p class="eyebrow"><?php echo esc_html( is_home() ? 'Journal' : 'Archive' ); ?></p>
    <h2 class="section-title"><?php echo esc_html( is_home() ? 'お知らせ' : wp_strip_all_tags( get_the_archive_title() ) ); ?></h2>
  </div>

  <?php if ( have_posts() ) : ?>
    <div class="entry-list">
      <?php
      while ( have_posts() ) :
          the_post();
          ?>
        <article <?php post_class( 'entry-card reveal' ); ?>>
          <p class="entry-date"><?php echo esc_html( get_the_date() ); ?></p>
          <h3 class="entry-title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
          </h3>
          <p class="entry-excerpt"><?php echo esc_html( get_the_excerpt() ); ?></p>
        </article>
        <?php
      endwhile;
      ?>
    </div>

    <?php
    the_posts_pagination(
        array(
            'mid_size'  => 1,
            'prev_text' => '←',
            'next_text' => '→',
        )
    );
    ?>

  <?php else : ?>
    <p><?php esc_html_e( 'まだ記事がありません。', 'lueur' ); ?></p>
  <?php endif; ?>
</section>

<?php
get_footer();
