<?php
/**
 * サイト共通のフッター。get_footer() から読み込まれます。
 *
 * @package Lueur
 */
?>
</main>

<footer class="site-footer">
  <div class="shell">
    <hr class="filament">

    <div class="footer-grid">
      <div class="footer-mark">
        <span class="brand-name"><?php bloginfo( 'name' ); ?></span>
        <span class="footer-tagline"><?php bloginfo( 'description' ); ?></span>
      </div>

      <nav class="footer-links" aria-label="<?php esc_attr_e( '外部リンク', 'lueur' ); ?>">
        <a href="<?php echo esc_url( lueur_option( 'instagram' ) ); ?>" rel="noopener">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true">
            <rect x="3" y="3" width="18" height="18" rx="5"/>
            <circle cx="12" cy="12" r="4.2"/>
            <circle cx="17.4" cy="6.6" r="1.1" fill="currentColor" stroke="none"/>
          </svg>Instagram
        </a>
        <a href="<?php echo esc_url( lueur_option( 'store' ) ); ?>"><?php esc_html_e( 'Online Store', 'lueur' ); ?></a>
        <a href="mailto:<?php echo esc_attr( lueur_option( 'email' ) ); ?>"><?php esc_html_e( 'お問い合わせ', 'lueur' ); ?></a>
      </nav>
    </div>

    <div class="colophon">
      <span>&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?></span>
      <span><?php echo esc_html( lueur_option( 'address' ) ); ?></span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
