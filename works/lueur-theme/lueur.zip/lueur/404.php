<?php
/**
 * ページが見つからないときの表示。
 *
 * @package Lueur
 */

get_header();
?>

<section class="shell entry-single">
  <div class="section-head">
    <p class="eyebrow">404</p>
    <h1 class="section-title"><?php esc_html_e( 'そのページは見つかりませんでした', 'lueur' ); ?></h1>
  </div>

  <div class="entry-body">
    <p><?php esc_html_e( 'お探しのページは、移動したか削除された可能性があります。', 'lueur' ); ?></p>
    <p><a href="<?php echo esc_url( home_url( '/' ) ); ?>">← <?php esc_html_e( 'トップへ戻る', 'lueur' ); ?></a></p>
  </div>
</section>

<?php
get_footer();
