<?php
/**
 * 記事の個別ページ。
 *
 * @package Lueur
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>
<article <?php post_class( 'shell entry-single' ); ?>>
  <div class="section-head">
    <p class="eyebrow"><?php echo esc_html( get_the_date() ); ?></p>
    <h1 class="section-title"><?php the_title(); ?></h1>
  </div>

  <?php if ( has_post_thumbnail() ) : ?>
  <figure class="photo photo--zoom"><?php the_post_thumbnail( 'large', array( 'loading' => 'lazy' ) ); ?></figure>
  <?php endif; ?>

  <div class="entry-body">
	<?php the_content(); ?>
  </div>

  <p class="entry-back"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">← <?php esc_html_e( 'トップへ戻る', 'lueur' ); ?></a></p>
</article>
	<?php
endwhile;

get_footer();
