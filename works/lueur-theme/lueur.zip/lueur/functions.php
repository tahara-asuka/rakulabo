<?php
/**
 * Lueur テーマの基本設定。
 *
 * WordPress は、テーマフォルダの functions.php を毎回読み込みます。
 * 「このテーマは何ができるか」をここで WordPress に伝えます。
 *
 * @package Lueur
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // 直接アクセスされたら止める（WordPress 経由でしか動かさない）
}

define( 'LUEUR_VERSION', '1.0.0' );

/* ------------------------------------------------------------------
 * 1. テーマがサポートする機能を宣言する
 * ---------------------------------------------------------------- */
function lueur_setup() {

	// <title> を WordPress に出力させる
	add_theme_support( 'title-tag' );

	// アイキャッチ画像を使えるようにする
	add_theme_support( 'post-thumbnails' );

	// HTML5 で出力する
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
	);

	// ブロックエディタの見た目を、表側の見た目に近づける
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'responsive-embeds' );
	add_editor_style( 'style.css' );

	// ナビゲーションメニューの置き場所を1つ登録する
	register_nav_menus(
		array(
			'primary' => __( 'ヘッダーのメニュー', 'lueur' ),
		)
	);

	load_theme_textdomain( 'lueur', get_template_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'lueur_setup' );

/* ------------------------------------------------------------------
 * 2. CSS と JavaScript を読み込む
 *    直接 <link> や <script> を書かず、必ずこの形で登録します。
 * ---------------------------------------------------------------- */
function lueur_assets() {

	// Google Fonts
	wp_enqueue_style(
		'lueur-fonts',
		'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300&family=Zen+Kaku+Gothic+New:wght@300;400;500&family=Zen+Old+Mincho:wght@400;500&display=swap',
		array(),
		null
	);

	// テーマ本体の CSS（style.css）
	wp_enqueue_style( 'lueur-style', get_stylesheet_uri(), array( 'lueur-fonts' ), LUEUR_VERSION );

	// メニューの開閉などの JavaScript
	wp_enqueue_script(
		'lueur-site',
		get_template_directory_uri() . '/js/site.js',
		array(),
		LUEUR_VERSION,
		true // </body> の直前に置く
	);
}
add_action( 'wp_enqueue_scripts', 'lueur_assets' );

/* ------------------------------------------------------------------
 * 3. 店舗情報の受け皿
 *    カスタマイザー（外観 > カスタマイズ）で編集できる値を取り出します。
 *    まだ何も入力されていないときは、初期値をそのまま返します。
 * ---------------------------------------------------------------- */
function lueur_defaults() {
	return array(
		'brand_sub'  => 'リュール',
		'hours_short'=> '8:00 – 18:00 ／ 水曜定休',
		'hours_long' => '8:00 – 18:00 ／ 水曜定休 ／ 池ノ上駅 徒歩5分',
		'address'    => '東京都世田谷区代沢 2-14-6　1F',
		'tel'        => '03-6804-XXXX',
		'instagram'  => '#',
		'store'      => '#',
		'email'      => 'hello@lueur.coffee',
	);
}

function lueur_option( $key ) {
	$defaults = lueur_defaults();
	$default  = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
	return get_theme_mod( 'lueur_' . $key, $default );
}

/* ------------------------------------------------------------------
 * 4. メニューが未設定のときに出す、初期のナビゲーション
 * ---------------------------------------------------------------- */
function lueur_default_nav() {
	$items = array(
		'#about'      => array( '当店について', 'About' ),
		'#philosophy' => array( 'こだわり', 'Philosophy' ),
		'#menu'       => array( 'メニュー', 'Menu' ),
		'#gallery'    => array( '店内の様子', 'Gallery' ),
		'#access'     => array( 'アクセス', 'Access' ),
	);

	echo '<ul class="nav-list">';
	foreach ( $items as $href => $label ) {
		printf(
			'<li><a href="%1$s">%2$s<em>%3$s</em></a></li>',
			esc_url( $href ),
			esc_html( $label[0] ),
			esc_html( $label[1] )
		);
	}
	echo '</ul>';
}

/* ------------------------------------------------------------------
 * 5. 分割したファイルを読み込む
 * ---------------------------------------------------------------- */
require_once get_template_directory() . '/inc/menu-cpt.php';   // メニュー（投稿タイプ）
require_once get_template_directory() . '/inc/customizer.php'; // 店舗情報の編集画面
