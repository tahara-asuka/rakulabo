<?php
/**
 * トップページ。
 *
 * WordPress は、フロントページを表示するとき front-page.php を最優先で使います。
 * セクションごとにファイルを分けて、get_template_part() で組み立てています。
 *
 * @package Lueur
 */

get_header();

get_template_part( 'template-parts/hero' );
get_template_part( 'template-parts/about' );
get_template_part( 'template-parts/philosophy' );
get_template_part( 'template-parts/menu' );
get_template_part( 'template-parts/gallery' );
get_template_part( 'template-parts/access' );

get_footer();
