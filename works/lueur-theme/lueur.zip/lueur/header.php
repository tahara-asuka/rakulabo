<?php
/**
 * サイト共通のヘッダー。
 * すべてのページの先頭で get_header() から読み込まれます。
 *
 * @package Lueur
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#FBFBFA">
<link rel="profile" href="https://gmpg.org/xfn/11">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#top"><?php esc_html_e( '本文へskip', 'lueur' ); ?></a>

<header class="site-header" id="siteHeader">
  <p class="header-hours"><?php echo esc_html( lueur_option( 'hours_short' ) ); ?></p>

  <a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
    <span class="brand-name"><?php bloginfo( 'name' ); ?></span>
    <span class="brand-sub"><?php echo esc_html( lueur_option( 'brand_sub' ) ); ?></span>
  </a>

  <button class="menu-toggle" id="menuOpen" aria-expanded="false" aria-controls="navOverlay">
    <?php esc_html_e( 'Menu', 'lueur' ); ?> <span></span>
  </button>
</header>

<nav class="nav-overlay" id="navOverlay" data-open="false" aria-label="<?php esc_attr_e( 'サイト内メニュー', 'lueur' ); ?>">
  <button class="nav-close" id="menuClose"><?php esc_html_e( 'Close ×', 'lueur' ); ?></button>

  <?php
  // 管理画面「外観 > メニュー」で作ったメニューを出力します。
  // まだ作られていないときは、初期メニューをそのまま表示します。
  if ( has_nav_menu( 'primary' ) ) {
      wp_nav_menu(
          array(
              'theme_location' => 'primary',
              'menu_class'     => 'nav-list',
              'container'      => false,
              'depth'          => 1,
          )
      );
  } else {
      lueur_default_nav();
  }
  ?>

  <p class="nav-foot">
    <?php echo esc_html( lueur_option( 'address' ) ); ?><br>
    <?php echo esc_html( lueur_option( 'hours_long' ) ); ?>
  </p>
</nav>

<main id="top">
