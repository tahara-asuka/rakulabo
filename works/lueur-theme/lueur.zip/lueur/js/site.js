(function () {
  var header  = document.getElementById('siteHeader');
  var overlay = document.getElementById('navOverlay');
  var openBtn = document.getElementById('menuOpen');
  var closeBtn= document.getElementById('menuClose');

  /* header gains a solid ground once past the hero */
  var hero = document.querySelector('.hero');
  if ('IntersectionObserver' in window && hero) {
    new IntersectionObserver(function (entries) {
      header.classList.toggle('is-stuck', !entries[0].isIntersecting);
    }, { rootMargin: '-80px 0px 0px 0px', threshold: 0 }).observe(hero);
  } else {
    header.classList.add('is-stuck');
  }

  function setNav(open) {
    overlay.dataset.open = open ? 'true' : 'false';
    openBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    document.body.style.overflow = open ? 'hidden' : '';
    if (open) { closeBtn.focus(); } else { openBtn.focus(); }
  }

  openBtn.addEventListener('click', function () { setNav(true); });
  closeBtn.addEventListener('click', function () { setNav(false); });
  overlay.addEventListener('click', function (e) { if (e.target === overlay) setNav(false); });
  overlay.querySelectorAll('a').forEach(function (a) {
    a.addEventListener('click', function () { setNav(false); });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && overlay.dataset.open === 'true') setNav(false);
  });
})();
